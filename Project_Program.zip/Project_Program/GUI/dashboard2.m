% function varargout = dashboard2(varargin)
% % DASHBOARD2 MATLAB code for dashboard2.fig
% %      DASHBOARD2, by itself, creates a new DASHBOARD2 or raises the existing
% %      singleton*.
% %
% %      H = DASHBOARD2 returns the handle to a new DASHBOARD2 or the handle to
% %      the existing singleton*.
% %
% %      DASHBOARD2('CALLBACK',hObject,eventData,handles,...) calls the local
% %      function named CALLBACK in DASHBOARD2.M with the given input arguments.
% %
% %      DASHBOARD2('Property','Value',...) creates a new DASHBOARD2 or raises the
% %      existing singleton*.  Starting from the left, property value pairs are
% %      applied to the GUI before dashboard2_OpeningFcn gets called.  An
% %      unrecognized property name or invalid value makes property application
% %      stop.  All inputs are passed to dashboard2_OpeningFcn via varargin.
% %
% %      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
% %      instance to run (singleton)".
% %
% % See also: GUIDE, GUIDATA, GUIHANDLES
% 
% % Edit the above text to modify the response to help dashboard2
% 
% % Last Modified by GUIDE v2.5 02-Apr-2021 21:48:55
% 
% % Begin initialization code - DO NOT EDIT
% gui_Singleton = 1;
% gui_State = struct('gui_Name',       mfilename, ...
%                    'gui_Singleton',  gui_Singleton, ...
%                    'gui_OpeningFcn', @dashboard2_OpeningFcn, ...
%                    'gui_OutputFcn',  @dashboard2_OutputFcn, ...
%                    'gui_LayoutFcn',  [] , ...
%                    'gui_Callback',   []);
% if nargin && ischar(varargin{1})
%     gui_State.gui_Callback = str2func(varargin{1});
% end
% 
% if nargout
%     [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
% else
%     gui_mainfcn(gui_State, varargin{:});
% end
% % End initialization code - DO NOT EDIT
% 
% 
% % --- Executes just before dashboard2 is made visible.
% function dashboard2_OpeningFcn(hObject, eventdata, handles, varargin)
% % This function has no output args, see OutputFcn.
% % hObject    handle to figure
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% % varargin   command line arguments to dashboard2 (see VARARGIN)
% 
% % Choose default command line output for dashboard2
% handles.output = hObject;
% 
% % Update handles structure
% guidata(hObject, handles);
% 
% % UIWAIT makes dashboard2 wait for user response (see UIRESUME)
% % uiwait(handles.figure1);
% 
% 
% 
% % --- Outputs from this function are returned to the command line.
% function varargout = dashboard2_OutputFcn(hObject, eventdata, handles) 
% % varargout  cell array for returning output args (see VARARGOUT);
% % hObject    handle to figure
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% % Get default command line output from handles structure
% varargout{1} = handles.output;
% 
% 
% % --- Executes on button press in pushbutton1.
% function pushbutton1_Callback(hObject, eventdata, handles)
% % hObject    handle to pushbutton1 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% dashboard;
% close(dashboard2);
% 
% % --- Executes on button press in pushbutton2.
% function pushbutton2_Callback(hObject, eventdata, handles)
% % hObject    handle to pushbutton2 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% 
% % --- Executes on button press in pushbutton4.
% function pushbutton4_Callback(hObject, eventdata, handles)
% % hObject    handle to pushbutton4 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% 
% % --- Executes on button press in pushbutton5.
% function pushbutton5_Callback(hObject, eventdata, handles)
% % hObject    handle to pushbutton5 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% logout;
% 
% 
% % --- Executes on button press in pushbutton6.
% function pushbutton6_Callback(hObject, eventdata, handles)
% % hObject    handle to pushbutton6 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% [file,path] = uigetfile('*.jpeg');
% if isequal(file,0)
%    disp('User selected Cancel');
% else
%    disp(['User selected ', fullfile(path,file)]);
% end

myImage = imread('C:\Users\Murtaza\OneDrive\FYP\Docs\NewDataSet\8.jpeg');
% axes(handles.axes1);
imshow(myImage);
title('Original Image','Color','white');
subplot(4,4,1);
imshow(image);
title('Original');
resize = imresize(myImage,[500 1000]);
subplot(4,4,2);
imshow(resize);
title('Resized');
BW = rgb2gray(resize);
subplot(4,4,3);
imshow(BW);
title('Black and White');
subplot(4,4,4);
imhist(BW);
title('Histogram');
new = histeq(BW);
subplot(4,4,5);
imshow(new);
subplot(4,4,6);
imhist(new,64);
title('Equalized Histogram');

binary = im2bw(new,0.07);
subplot(4,4,7);
imshow(binary);
title('Binary Image');  

BW2 = edge(binary,'canny',0.99);
subplot(4,4,8);
imshow(BW2);
title('Canny Filter'); 
Invert Image
invert=imcomplement(BW2);
subplot(4,4,9);
imshow(invert);
title('Invert');

Image Segmentation
se90 = strel('square',7);
se0 = strel('line',3,0);
BWsdil = imdilate(BW2,se90);
subplot(4,4,10);
imshow(BWsdil)
title('Dilated Gradient Mask')

%
BWdfill = imfill(BWsdil,'holes');
subplot(4,4,11);
imshow(BWdfill)
title('Binary Image with Filled Holes')

seD = strel('disk',1,4);
BWfinal = imerode(BWdfill,seD);
BWfinal = imerode(BWfinal,seD);
subplot(4,4,12);
imshow(BWfinal)
title('Segmented Image');

BWoutline = bwperim(BWfinal);
Segout = BW; 
Segout(BWoutline) = 255; 
subplot(4,4,13);
imshow(Segout)
title('Outlined Original Image')
axes(handles.axes3);
imshow(Segout);
title('Outlined Original Image','Color','white');





% --- Executes on button press in pushbutton7.
% function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
