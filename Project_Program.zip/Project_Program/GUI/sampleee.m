conn = database('DataBase','','');
query = 'select InspectorName from UserSignUp';
curs = exec(conn, query);
curs = fetch(curs);
curs.Data;
rows=sqlread(conn,'UserSignUp');
tail(rows);
%query2='insert into UserSignUp(InspectorID,InspectorName,Email Address, Password) values ('HEL123','Hello','Hey@gmail.com','123')';